var mime_samples = [
  { 'mime': 'application/xhtml+xml', 'samples': [
    { 'url': 'http://bankold.com/', 'dir': '_m0/0', 'linked': 2, 'len': 1155 },
    { 'url': 'http://bankold.com/web/registration.php', 'dir': '_m0/1', 'linked': 2, 'len': 1651 },
    { 'url': 'http://bankold.com/css/', 'dir': '_m0/2', 'linked': 2, 'len': 1089 },
    { 'url': 'http://bankold.com/icons/', 'dir': '_m0/3', 'linked': 2, 'len': 73983 },
    { 'url': 'http://bankold.com/icons/small/', 'dir': '_m0/4', 'linked': 2, 'len': 14299 },
    { 'url': 'http://bankold.com/web/', 'dir': '_m0/5', 'linked': 5, 'len': 2610 },
    { 'url': 'http://bankold.com/web/registration.php', 'dir': '_m0/6', 'linked': 5, 'len': 1904 },
    { 'url': 'http://bankold.com/web/reset.php', 'dir': '_m0/7', 'linked': 5, 'len': 1400 },
    { 'url': 'http://bankold.com/web/reset.php', 'dir': '_m0/8', 'linked': 5, 'len': 1636 } ]
  },
  { 'mime': 'image/gif', 'samples': [
    { 'url': 'http://bankold.com/icons/small/back.gif', 'dir': '_m1/0', 'linked': 2, 'len': 129 },
    { 'url': 'http://bankold.com/icons/small/blank.gif', 'dir': '_m1/1', 'linked': 2, 'len': 55 },
    { 'url': 'http://bankold.com/icons/small/broken.gif', 'dir': '_m1/2', 'linked': 2, 'len': 139 },
    { 'url': 'http://bankold.com/icons/small/comp1.gif', 'dir': '_m1/3', 'linked': 2, 'len': 130 },
    { 'url': 'http://bankold.com/icons/small/folder2.gif', 'dir': '_m1/4', 'linked': 2, 'len': 122 },
    { 'url': 'http://bankold.com/icons/small/ps.gif', 'dir': '_m1/5', 'linked': 2, 'len': 184 },
    { 'url': 'http://bankold.com/icons/small/rainbow.gif', 'dir': '_m1/6', 'linked': 2, 'len': 3811 },
    { 'url': 'http://bankold.com/icons/alert.black.gif', 'dir': '_m1/7', 'linked': 2, 'len': 242 },
    { 'url': 'http://bankold.com/icons/apache_pb.gif', 'dir': '_m1/8', 'linked': 2, 'len': 4463 },
    { 'url': 'http://bankold.com/icons/apache_pb2.gif', 'dir': '_m1/9', 'linked': 2, 'len': 4234 },
    { 'url': 'http://bankold.com/icons/ball.gray.gif', 'dir': '_m1/10', 'linked': 2, 'len': 233 },
    { 'url': 'http://bankold.com/icons/binary.gif', 'dir': '_m1/11', 'linked': 2, 'len': 246 },
    { 'url': 'http://bankold.com/icons/box2.gif', 'dir': '_m1/12', 'linked': 2, 'len': 268 },
    { 'url': 'http://bankold.com/icons/compressed.gif', 'dir': '_m1/13', 'linked': 2, 'len': 1038 },
    { 'url': 'http://bankold.com/icons/hand.right.gif', 'dir': '_m1/14', 'linked': 2, 'len': 217 },
    { 'url': 'http://bankold.com/icons/icon.sheet.gif', 'dir': '_m1/15', 'linked': 2, 'len': 11977 },
    { 'url': 'http://bankold.com/icons/image3.gif', 'dir': '_m1/16', 'linked': 2, 'len': 286 },
    { 'url': 'http://bankold.com/icons/index.gif', 'dir': '_m1/17', 'linked': 2, 'len': 268 },
    { 'url': 'http://bankold.com/icons/movie.gif', 'dir': '_m1/18', 'linked': 2, 'len': 243 },
    { 'url': 'http://bankold.com/icons/screw1.gif', 'dir': '_m1/19', 'linked': 2, 'len': 258 },
    { 'url': 'http://bankold.com/icons/screw2.gif', 'dir': '_m1/20', 'linked': 2, 'len': 263 } ]
  },
  { 'mime': 'image/png', 'samples': [
    { 'url': 'http://bankold.com/icons/small/back.png', 'dir': '_m2/0', 'linked': 2, 'len': 181 },
    { 'url': 'http://bankold.com/icons/small/blank.png', 'dir': '_m2/1', 'linked': 2, 'len': 100 },
    { 'url': 'http://bankold.com/icons/small/broken.png', 'dir': '_m2/2', 'linked': 2, 'len': 184 },
    { 'url': 'http://bankold.com/icons/small/burst.png', 'dir': '_m2/3', 'linked': 2, 'len': 210 },
    { 'url': 'http://bankold.com/icons/small/comp1.png', 'dir': '_m2/4', 'linked': 2, 'len': 216 },
    { 'url': 'http://bankold.com/icons/small/compressed.png', 'dir': '_m2/5', 'linked': 2, 'len': 212 },
    { 'url': 'http://bankold.com/icons/small/folder2.png', 'dir': '_m2/6', 'linked': 2, 'len': 180 },
    { 'url': 'http://bankold.com/icons/small/rainbow.png', 'dir': '_m2/7', 'linked': 2, 'len': 2427 },
    { 'url': 'http://bankold.com/icons/apache_pb.png', 'dir': '_m2/8', 'linked': 2, 'len': 9691 },
    { 'url': 'http://bankold.com/icons/apache_pb2.png', 'dir': '_m2/9', 'linked': 2, 'len': 10401 },
    { 'url': 'http://bankold.com/icons/back.png', 'dir': '_m2/10', 'linked': 2, 'len': 308 },
    { 'url': 'http://bankold.com/icons/binhex.png', 'dir': '_m2/11', 'linked': 2, 'len': 319 },
    { 'url': 'http://bankold.com/icons/compressed.png', 'dir': '_m2/12', 'linked': 2, 'len': 1108 },
    { 'url': 'http://bankold.com/icons/dir.png', 'dir': '_m2/13', 'linked': 2, 'len': 295 },
    { 'url': 'http://bankold.com/icons/odf6odb.png', 'dir': '_m2/14', 'linked': 2, 'len': 1047 },
    { 'url': 'http://bankold.com/icons/odf6odc.png', 'dir': '_m2/15', 'linked': 2, 'len': 1000 },
    { 'url': 'http://bankold.com/icons/odf6odg.png', 'dir': '_m2/16', 'linked': 2, 'len': 1072 },
    { 'url': 'http://bankold.com/icons/odf6odp.png', 'dir': '_m2/17', 'linked': 2, 'len': 978 },
    { 'url': 'http://bankold.com/icons/odf6ots.png', 'dir': '_m2/18', 'linked': 2, 'len': 1010 } ]
  },
  { 'mime': 'image/svg+xml', 'samples': [
    { 'url': 'http://bankold.com/icons/apache_pb.svg', 'dir': '_m3/0', 'linked': 2, 'len': 266455 } ]
  },
  { 'mime': 'text/css', 'samples': [
    { 'url': 'http://bankold.com/css/reset.css', 'dir': '_m4/0', 'linked': 2, 'len': 1401 },
    { 'url': 'http://bankold.com/css/style.css', 'dir': '_m4/1', 'linked': 2, 'len': 1634 } ]
  },
  { 'mime': 'text/html', 'samples': [
    { 'url': 'http://bankold.com/web/login.php', 'dir': '_m5/0', 'linked': 5, 'len': 166 } ]
  }
];

var issue_samples = [
  { 'severity': 3, 'type': 40402, 'samples': [
    { 'url': 'http://bankold.com/web/login.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/0' },
    { 'url': 'http://bankold.com/web/login.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/1' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/2' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/3' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/4' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/5' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/6' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/7' },
    { 'url': 'http://bankold.com/web/reset.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/8' },
    { 'url': 'http://bankold.com/web/reset.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/9' },
    { 'url': 'http://bankold.com/web/reset.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/10' },
    { 'url': 'http://bankold.com/web/reset.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i0/11' } ]
  },
  { 'severity': 0, 'type': 10803, 'samples': [
    { 'url': 'http://bankold.com/css/reset.css', 'extra': '', 'sid': '0', 'dir': '_i1/0' },
    { 'url': 'http://bankold.com/css/style.css', 'extra': '', 'sid': '0', 'dir': '_i1/1' },
    { 'url': 'http://bankold.com/icons/apache_pb.svg', 'extra': '', 'sid': '0', 'dir': '_i1/2' } ]
  },
  { 'severity': 0, 'type': 10602, 'samples': [
    { 'url': 'http://bankold.com/web/login.php', 'extra': '', 'sid': '0', 'dir': '_i2/0' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i2/1' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i2/2' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i2/3' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i2/4' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i2/5' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i2/6' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i2/7' },
    { 'url': 'http://bankold.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i2/8' },
    { 'url': 'http://bankold.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i2/9' },
    { 'url': 'http://bankold.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i2/10' },
    { 'url': 'http://bankold.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i2/11' },
    { 'url': 'http://bankold.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i2/12' } ]
  },
  { 'severity': 0, 'type': 10505, 'samples': [
    { 'url': 'http://bankold.com/web/registration.php', 'extra': 'pesel', 'sid': '0', 'dir': '_i3/0' } ]
  },
  { 'severity': 0, 'type': 10404, 'samples': [
    { 'url': 'http://bankold.com/css/', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/0' },
    { 'url': 'http://bankold.com/css/?C=9876sfi;O=D', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/1' },
    { 'url': 'http://bankold.com/css/?C=N;O=9876sfi', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/2' },
    { 'url': 'http://bankold.com/icons/', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/3' },
    { 'url': 'http://bankold.com/icons/small/', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/4' },
    { 'url': 'http://bankold.com/icons/small/?C=9876sfi;O=D', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/5' },
    { 'url': 'http://bankold.com/icons/small/?C=N;O=9876sfi', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/6' },
    { 'url': 'http://bankold.com/icons/?C=9876sfi;O=D', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/7' },
    { 'url': 'http://bankold.com/icons/?C=N;O=9876sfi', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/8' },
    { 'url': 'http://bankold.com/web/', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/9' },
    { 'url': 'http://bankold.com/web/?C=9876sfi;O=D', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/10' },
    { 'url': 'http://bankold.com/web/?C=N;O=9876sfi', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i4/11' } ]
  },
  { 'severity': 0, 'type': 10205, 'samples': [
    { 'url': 'http://bankold.com/sfi9876', 'extra': '', 'sid': '0', 'dir': '_i5/0' } ]
  },
  { 'severity': 0, 'type': 10204, 'samples': [
    { 'url': 'http://bankold.com/', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i6/0' },
    { 'url': 'http://bankold.com/css/', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i6/1' },
    { 'url': 'http://bankold.com/icons/', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i6/2' },
    { 'url': 'http://bankold.com/web/', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i6/3' },
    { 'url': 'http://bankold.com/web/acceptPay.php', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i6/4' },
    { 'url': 'http://bankold.com/web/login.php', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i6/5' },
    { 'url': 'http://bankold.com/web/registration.php', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i6/6' },
    { 'url': 'http://bankold.com/web/reset.php', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i6/7' } ]
  },
  { 'severity': 0, 'type': 10202, 'samples': [
    { 'url': 'http://bankold.com/', 'extra': 'Apache/2.4.35 (Unix) OpenSSL/1.0.2p PHP/7.2.11 mod_perl/2.0.8-dev Perl/v5.16.3', 'sid': '0', 'dir': '_i7/0' } ]
  }
];

