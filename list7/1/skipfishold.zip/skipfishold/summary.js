var sf_version = '2.10b';
var scan_date  = 'Sun Dec  9 21:32:52 2018';
var scan_seed  = '0x7bef7cb7';
var scan_ms    = 17899;
