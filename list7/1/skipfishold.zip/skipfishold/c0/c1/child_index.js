var child = [
  { 'dupe': false, 'type': 4, 'name': 'daniel', 'dir': 'c0', 'linked': 1, 'url': 'http://bankold.com/home/daniel/', 'fetched': true, 'code': 404, 'len': 1192, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': true, 'csens': false, 'child_cnt': 2, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x42158427 }
];
