var child = [
  { 'dupe': false, 'type': 2, 'name': 'http://bankold.com/', 'dir': 'c0', 'linked': 2, 'url': 'http://bankold.com/', 'fetched': true, 'code': 200, 'len': 1155, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'missing': false, 'csens': true, 'child_cnt': 85, 'issue_cnt': [ 39, 0, 0, 12, 0 ], 'sig': 0xec04a862 }
];
