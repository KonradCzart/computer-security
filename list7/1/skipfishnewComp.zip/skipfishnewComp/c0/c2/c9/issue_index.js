var issue = [
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 266455, 'decl_mime': 'image/svg+xml', 'sniff_mime': 'image/svg+xml', 'cset': '[none]', 'dir': 'i0' }
];
