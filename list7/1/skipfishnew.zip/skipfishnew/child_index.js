var child = [
  { 'dupe': false, 'type': 2, 'name': 'http://banknew.com/', 'dir': 'c0', 'linked': 2, 'url': 'http://banknew.com/', 'fetched': true, 'code': 200, 'len': 1155, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'missing': false, 'csens': true, 'child_cnt': 86, 'issue_cnt': [ 42, 0, 0, 13, 1 ], 'sig': 0xec00a862 }
];
