var mime_samples = [
  { 'mime': 'application/xhtml+xml', 'samples': [
    { 'url': 'http://banknew.com/', 'dir': '_m0/0', 'linked': 2, 'len': 1155 },
    { 'url': 'http://banknew.com/web/reset.php', 'dir': '_m0/1', 'linked': 2, 'len': 1400 },
    { 'url': 'http://banknew.com/css/', 'dir': '_m0/2', 'linked': 2, 'len': 1089 },
    { 'url': 'http://banknew.com/icons/', 'dir': '_m0/3', 'linked': 2, 'len': 73983 },
    { 'url': 'http://banknew.com/icons/small/', 'dir': '_m0/4', 'linked': 2, 'len': 14299 },
    { 'url': 'http://banknew.com/web/', 'dir': '_m0/5', 'linked': 5, 'len': 2610 },
    { 'url': 'http://banknew.com/web/registration.php', 'dir': '_m0/6', 'linked': 5, 'len': 1651 },
    { 'url': 'http://banknew.com/web/registration.php', 'dir': '_m0/7', 'linked': 5, 'len': 1905 },
    { 'url': 'http://banknew.com/web/reset.php', 'dir': '_m0/8', 'linked': 5, 'len': 1637 } ]
  },
  { 'mime': 'image/gif', 'samples': [
    { 'url': 'http://banknew.com/icons/small/back.gif', 'dir': '_m1/0', 'linked': 2, 'len': 129 },
    { 'url': 'http://banknew.com/icons/small/blank.gif', 'dir': '_m1/1', 'linked': 2, 'len': 55 },
    { 'url': 'http://banknew.com/icons/small/broken.gif', 'dir': '_m1/2', 'linked': 2, 'len': 139 },
    { 'url': 'http://banknew.com/icons/small/comp1.gif', 'dir': '_m1/3', 'linked': 2, 'len': 130 },
    { 'url': 'http://banknew.com/icons/small/folder2.gif', 'dir': '_m1/4', 'linked': 2, 'len': 122 },
    { 'url': 'http://banknew.com/icons/small/ps.gif', 'dir': '_m1/5', 'linked': 2, 'len': 184 },
    { 'url': 'http://banknew.com/icons/small/rainbow.gif', 'dir': '_m1/6', 'linked': 2, 'len': 3811 },
    { 'url': 'http://banknew.com/icons/alert.black.gif', 'dir': '_m1/7', 'linked': 2, 'len': 242 },
    { 'url': 'http://banknew.com/icons/apache_pb.gif', 'dir': '_m1/8', 'linked': 2, 'len': 4463 },
    { 'url': 'http://banknew.com/icons/apache_pb2.gif', 'dir': '_m1/9', 'linked': 2, 'len': 4234 },
    { 'url': 'http://banknew.com/icons/ball.gray.gif', 'dir': '_m1/10', 'linked': 2, 'len': 233 },
    { 'url': 'http://banknew.com/icons/binary.gif', 'dir': '_m1/11', 'linked': 2, 'len': 246 },
    { 'url': 'http://banknew.com/icons/box2.gif', 'dir': '_m1/12', 'linked': 2, 'len': 268 },
    { 'url': 'http://banknew.com/icons/compressed.gif', 'dir': '_m1/13', 'linked': 2, 'len': 1038 },
    { 'url': 'http://banknew.com/icons/hand.right.gif', 'dir': '_m1/14', 'linked': 2, 'len': 217 },
    { 'url': 'http://banknew.com/icons/icon.sheet.gif', 'dir': '_m1/15', 'linked': 2, 'len': 11977 },
    { 'url': 'http://banknew.com/icons/image3.gif', 'dir': '_m1/16', 'linked': 2, 'len': 286 },
    { 'url': 'http://banknew.com/icons/index.gif', 'dir': '_m1/17', 'linked': 2, 'len': 268 },
    { 'url': 'http://banknew.com/icons/movie.gif', 'dir': '_m1/18', 'linked': 2, 'len': 243 },
    { 'url': 'http://banknew.com/icons/screw1.gif', 'dir': '_m1/19', 'linked': 2, 'len': 258 },
    { 'url': 'http://banknew.com/icons/screw2.gif', 'dir': '_m1/20', 'linked': 2, 'len': 263 } ]
  },
  { 'mime': 'image/png', 'samples': [
    { 'url': 'http://banknew.com/icons/small/back.png', 'dir': '_m2/0', 'linked': 2, 'len': 181 },
    { 'url': 'http://banknew.com/icons/small/blank.png', 'dir': '_m2/1', 'linked': 2, 'len': 100 },
    { 'url': 'http://banknew.com/icons/small/broken.png', 'dir': '_m2/2', 'linked': 2, 'len': 184 },
    { 'url': 'http://banknew.com/icons/small/burst.png', 'dir': '_m2/3', 'linked': 2, 'len': 210 },
    { 'url': 'http://banknew.com/icons/small/comp1.png', 'dir': '_m2/4', 'linked': 2, 'len': 216 },
    { 'url': 'http://banknew.com/icons/small/compressed.png', 'dir': '_m2/5', 'linked': 2, 'len': 212 },
    { 'url': 'http://banknew.com/icons/small/folder2.png', 'dir': '_m2/6', 'linked': 2, 'len': 180 },
    { 'url': 'http://banknew.com/icons/small/rainbow.png', 'dir': '_m2/7', 'linked': 2, 'len': 2427 },
    { 'url': 'http://banknew.com/icons/apache_pb.png', 'dir': '_m2/8', 'linked': 2, 'len': 9691 },
    { 'url': 'http://banknew.com/icons/apache_pb2.png', 'dir': '_m2/9', 'linked': 2, 'len': 10401 },
    { 'url': 'http://banknew.com/icons/back.png', 'dir': '_m2/10', 'linked': 2, 'len': 308 },
    { 'url': 'http://banknew.com/icons/binhex.png', 'dir': '_m2/11', 'linked': 2, 'len': 319 },
    { 'url': 'http://banknew.com/icons/compressed.png', 'dir': '_m2/12', 'linked': 2, 'len': 1108 },
    { 'url': 'http://banknew.com/icons/dir.png', 'dir': '_m2/13', 'linked': 2, 'len': 295 },
    { 'url': 'http://banknew.com/icons/odf6odb.png', 'dir': '_m2/14', 'linked': 2, 'len': 1047 },
    { 'url': 'http://banknew.com/icons/odf6odc.png', 'dir': '_m2/15', 'linked': 2, 'len': 1000 },
    { 'url': 'http://banknew.com/icons/odf6odg.png', 'dir': '_m2/16', 'linked': 2, 'len': 1072 },
    { 'url': 'http://banknew.com/icons/odf6odp.png', 'dir': '_m2/17', 'linked': 2, 'len': 978 },
    { 'url': 'http://banknew.com/icons/odf6ots.png', 'dir': '_m2/18', 'linked': 2, 'len': 1010 } ]
  },
  { 'mime': 'image/svg+xml', 'samples': [
    { 'url': 'http://banknew.com/icons/apache_pb.svg', 'dir': '_m3/0', 'linked': 2, 'len': 266455 } ]
  },
  { 'mime': 'text/css', 'samples': [
    { 'url': 'http://banknew.com/css/reset.css', 'dir': '_m4/0', 'linked': 2, 'len': 1401 },
    { 'url': 'http://banknew.com/css/style.css', 'dir': '_m4/1', 'linked': 2, 'len': 1661 } ]
  },
  { 'mime': 'text/html', 'samples': [
    { 'url': 'http://banknew.com/web/login.php', 'dir': '_m5/0', 'linked': 5, 'len': 167 } ]
  }
];

var issue_samples = [
  { 'severity': 4, 'type': 50103, 'samples': [
    { 'url': 'http://banknew.com/web/history.php/9-8', 'extra': 'response suggests arithmetic evaluation on server side (type 1)', 'sid': '0', 'dir': '_i0/0' } ]
  },
  { 'severity': 3, 'type': 40402, 'samples': [
    { 'url': 'http://banknew.com/web/history.php/9-1', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/0' },
    { 'url': 'http://banknew.com/web/login.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/1' },
    { 'url': 'http://banknew.com/web/login.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/2' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/3' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/4' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/5' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/6' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/7' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/8' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/9' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/10' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/11' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': 'PHP notice (HTML)', 'sid': '22012', 'dir': '_i1/12' } ]
  },
  { 'severity': 0, 'type': 10803, 'samples': [
    { 'url': 'http://banknew.com/css/reset.css', 'extra': '', 'sid': '0', 'dir': '_i2/0' },
    { 'url': 'http://banknew.com/css/style.css', 'extra': '', 'sid': '0', 'dir': '_i2/1' },
    { 'url': 'http://banknew.com/icons/apache_pb.svg', 'extra': '', 'sid': '0', 'dir': '_i2/2' } ]
  },
  { 'severity': 0, 'type': 10602, 'samples': [
    { 'url': 'http://banknew.com/web/login.php', 'extra': '', 'sid': '0', 'dir': '_i3/0' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i3/1' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i3/2' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i3/3' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i3/4' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i3/5' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i3/6' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i3/7' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': '', 'sid': '0', 'dir': '_i3/8' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i3/9' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i3/10' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i3/11' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i3/12' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i3/13' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': '', 'sid': '0', 'dir': '_i3/14' } ]
  },
  { 'severity': 0, 'type': 10505, 'samples': [
    { 'url': 'http://banknew.com/web/reset.php', 'extra': 'pesel', 'sid': '0', 'dir': '_i4/0' } ]
  },
  { 'severity': 0, 'type': 10404, 'samples': [
    { 'url': 'http://banknew.com/css/', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/0' },
    { 'url': 'http://banknew.com/css/?C=9876sfi;O=D', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/1' },
    { 'url': 'http://banknew.com/css/?C=N;O=9876sfi', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/2' },
    { 'url': 'http://banknew.com/icons/', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/3' },
    { 'url': 'http://banknew.com/icons/small/', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/4' },
    { 'url': 'http://banknew.com/icons/small/?C=9876sfi;O=D', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/5' },
    { 'url': 'http://banknew.com/icons/small/?C=N;O=9876sfi', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/6' },
    { 'url': 'http://banknew.com/icons/?C=9876sfi;O=D', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/7' },
    { 'url': 'http://banknew.com/icons/?C=N;O=9876sfi', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/8' },
    { 'url': 'http://banknew.com/web/', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/9' },
    { 'url': 'http://banknew.com/web/?C=9876sfi;O=D', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/10' },
    { 'url': 'http://banknew.com/web/?C=N;O=9876sfi', 'extra': 'Directory listing', 'sid': '0', 'dir': '_i5/11' } ]
  },
  { 'severity': 0, 'type': 10205, 'samples': [
    { 'url': 'http://banknew.com/sfi9876', 'extra': '', 'sid': '0', 'dir': '_i6/0' } ]
  },
  { 'severity': 0, 'type': 10204, 'samples': [
    { 'url': 'http://banknew.com/', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i7/0' },
    { 'url': 'http://banknew.com/css/', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i7/1' },
    { 'url': 'http://banknew.com/icons/', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i7/2' },
    { 'url': 'http://banknew.com/web/', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i7/3' },
    { 'url': 'http://banknew.com/web/acceptPay.php', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i7/4' },
    { 'url': 'http://banknew.com/web/history.php', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i7/5' },
    { 'url': 'http://banknew.com/web/login.php', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i7/6' },
    { 'url': 'http://banknew.com/web/registration.php', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i7/7' },
    { 'url': 'http://banknew.com/web/reset.php', 'extra': 'X-Powered-By', 'sid': '0', 'dir': '_i7/8' } ]
  },
  { 'severity': 0, 'type': 10202, 'samples': [
    { 'url': 'http://banknew.com/', 'extra': 'Apache/2.4.35 (Unix) OpenSSL/1.0.2p PHP/7.2.11 mod_perl/2.0.8-dev Perl/v5.16.3', 'sid': '0', 'dir': '_i8/0' } ]
  }
];

