var child = [
  { 'dupe': false, 'type': 4, 'name': 'lampp', 'dir': 'c0', 'linked': 1, 'url': 'http://banknew.com/opt/lampp/', 'fetched': true, 'code': 404, 'len': 1192, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': true, 'csens': false, 'child_cnt': 4, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x3189631b }
];
