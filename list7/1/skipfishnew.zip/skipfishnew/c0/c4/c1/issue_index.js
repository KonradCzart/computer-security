var issue = [
  { 'severity': 4, 'type': 50103, 'sid': '0', 'extra': 'response suggests arithmetic evaluation on server side (type 1)', 'fetched': true, 'code': 302, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i0' },
  { 'severity': 3, 'type': 40402, 'sid': '22012', 'extra': 'PHP notice (HTML)', 'fetched': true, 'code': 200, 'len': 1540, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i1' },
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-Powered-By', 'fetched': true, 'code': 302, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i2' }
];
