var child = [
  { 'dupe': false, 'type': 64, 'name': 'password=skipfish', 'dir': 'c0', 'linked': 5, 'url': 'http://banknew.com/web/login.php DATA:username=Smith&password=skipfish', 'fetched': true, 'code': 302, 'len': 167, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': 'UTF-8', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 1, 0 ], 'sig': 0xe687d3a0 },
  { 'dupe': false, 'type': 64, 'name': 'username=Smith', 'dir': 'c1', 'linked': 5, 'url': 'http://banknew.com/web/login.php DATA:username=Smith&password=skipfish', 'fetched': true, 'code': 302, 'len': 167, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': 'UTF-8', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 1, 0 ], 'sig': 0xe687d3a0 }
];
